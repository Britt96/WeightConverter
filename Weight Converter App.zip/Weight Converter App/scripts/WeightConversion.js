"use strict"
/*
  Title: WeightConversion
  Author: Brittny Eaddy
  Date: 7/18/2020
  Purpose: Provide function to perform a calculation converting
    pounds to kilograms and display the results in a table.
*/

/*
  updateTable will retrieve user input of pounds then plug it into the
  equation lbs * 0.45359237, rounding it to the hundreths. It will then
  display the result in the kgDisplay cell of the weight table
*/
function updateTable() {
   var kilogram = (document.getElementById("pounds").value * 0.45359237).toFixed(2);

   document.getElementById("kgDisplay").innerHTML = kilogram;
}
